# DentiScan - Starter Pipeline

A runnable skeleton of the two-model pipeline described in the project plan:
food classification (sugar/acidity -> Good/Moderation/Harmful) + dental risk
prediction (demographics/lifestyle -> caries risk), merged into a final
recommendation.

## Files

- `sample_food_data.csv` - small hand-built nutrition table (stand-in for
  Open Food Facts / USDA FoodData Central).
- `food_classifier.py` - labels foods with a dental-domain rule, then trains
  a Decision Tree to generalize that rule to new foods. Run first.
- `generate_dental_risk_data.py` - generates a synthetic demographic/lifestyle
  dataset (stand-in for NHANES or the Hugging Face oral-health dataset).
- `dental_risk_model.py` - trains a Random Forest to predict caries risk from
  that data. Run second.
- `dentiscan_demo.py` - loads both trained models and shows the full flow:
  scan a food -> classify it -> combine with user risk -> final message.

## Run order

```bash
pip install pandas scikit-learn joblib numpy
python food_classifier.py          # trains + saves food_classifier.joblib
python generate_dental_risk_data.py  # creates dental_risk_data.csv
python dental_risk_model.py        # trains + saves dental_risk_model.joblib
python dentiscan_demo.py           # runs the combined pipeline
```

## Running the web app (`dentiscan_app.py`)

The trained `.joblib` files are already included, so you can skip straight
to the app:

```bash
pip install -r requirements.txt
streamlit run dentiscan_app.py
```

This opens a local webpage where you fill in a one-time profile, then search
(or manually enter) a food and get a combined food-category + personal-risk
recommendation, with a running session history table.

Note: this sandbox has no internet access, so `streamlit` couldn't be
installed or run here to screenshot it - the app reuses the exact
`predict_food`, `predict_risk`, and `get_recommendation` functions that were
already tested end to end in `dentiscan_demo.py`, so the underlying logic is
verified even though the page itself wasn't rendered in this environment.
Run it locally to see it live.

### Turning this into the barcode-scan feature

Add a JS barcode scanner (e.g. [html5-qrcode](https://github.com/mebjas/html5-qrcode))
via a small Streamlit custom component, or use `streamlit-webrtc` for camera
access. On a successful scan, call the Open Food Facts product API with the
barcode (`https://world.openfoodfacts.org/api/v2/product/{barcode}.json`),
pull `sugars_100g`, and feed it into the same `nutrients` dict used by the
manual-entry tab in `dentiscan_app.py`.

### Deploying it

Push this folder to a GitHub repo, then deploy for free on
[Streamlit Community Cloud](https://streamlit.io/cloud) by pointing it at
`dentiscan_app.py`.

## Swapping in real data

- **Food data**: replace `sample_food_data.csv` with an export from
  [Open Food Facts](https://world.openfoodfacts.org/data) (barcode lookups,
  good for the "scan a barcode" feature) or
  [USDA FoodData Central](https://fdc.nal.usda.gov/download-datasets) (whole
  foods). Keep the same column names, or update `food_classifier.py`'s
  `label_food()` and feature list to match your new columns.
- **Dental risk data**: replace `dental_risk_data.csv` with a cleaned extract
  from [NHANES](https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Examination)
  (merge Oral Health Examination + Demographics + Dietary files on `SEQN`) or
  the [Hugging Face oral health dataset](https://huggingface.co/datasets/Ontlametse/Tsu_Data).
  Update `dental_risk_model.py`'s feature lists to match the real columns
  (e.g. NHANES uses coded variable names you'll want to rename first).

## For your report

- `food_classifier.py` prints the learned decision-tree rules - use this as
  your "how the model decides" explanation.
- `dental_risk_model.py` prints feature importances and ROC AUC - use this
  for your results/evaluation section.
- The labeling rule in `label_food()` is a good place to cite dental-health
  literature (sugar frequency, acidity, food stickiness/retention time) to
  justify your thresholds.
